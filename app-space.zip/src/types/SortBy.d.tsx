export type SortOptions = {
  name: string;
  encodedName: string;
}[];
